<?php

$servidor='localhost:3306';
$user='leveleur_reg';
$pass='AHAqRPsVu%gJ';
$db='leveleur_registro';

$conexion=new mysqli($servidor,$user,$pass,$db);

?>