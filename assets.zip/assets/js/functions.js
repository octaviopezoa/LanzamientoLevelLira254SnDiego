$(document).ready(function() {
  console.log("live!");
});
